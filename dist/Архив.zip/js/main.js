 $(document).ready(function() {
 
$('.lazy').slick({
  lazyLoad: 'ondemand',
  slidesToShow: 3,
  slidesToScroll: 1
});     
    
    
});
 
